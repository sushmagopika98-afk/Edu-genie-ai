import json
import re
from gemini_client import generate


def clean_json_block(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def generate_quiz(passage: str):
    prompt = f"""
Generate exactly 3 multiple-choice questions from the passage below.

Return ONLY valid JSON in this format:
[
  {{
    "question": "Question text",
    "options": ["A", "B", "C", "D"],
    "correct_answer": "A"
  }}
]

Passage:
{passage}
"""

    raw = generate(prompt)
    cleaned = clean_json_block(raw)

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return {
            "error": "The model returned invalid JSON.",
            "raw_response": raw
        }
