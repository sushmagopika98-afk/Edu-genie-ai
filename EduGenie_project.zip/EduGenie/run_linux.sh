#!/bin/bash
set -e
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo
echo Set your Gemini API key before starting:
echo   export GEMINI_API_KEY="YOUR_KEY"
echo
uvicorn main:app --reload
