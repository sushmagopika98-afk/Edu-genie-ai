@echo off
python -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Set your Gemini API key before starting:
echo   set GEMINI_API_KEY=YOUR_KEY
echo.
echo Starting EduGenie...
uvicorn main:app --reload
