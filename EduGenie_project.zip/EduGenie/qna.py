from gemini_client import generate


def answer_question(question: str) -> str:
    prompt = f"""
You are EduGenie, an educational assistant.
Answer the student's question accurately and concisely.
Use simple language and explain important terms when useful.

Student question:
{question}
"""
    return generate(prompt)
