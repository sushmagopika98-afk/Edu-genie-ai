import os

_model = None


def explain_topic(topic: str) -> str:
    """
    Uses the lightweight LaMini-Flan-T5 model described in the project
    documentation. The model is loaded lazily so the rest of EduGenie can
    start without downloading a large model until /explain is used.
    """
    global _model

    try:
        from transformers import pipeline
    except ImportError:
        return (
            "The explanation model dependencies are not installed. "
            "Run: pip install -r requirements.txt"
        )

    model_name = os.getenv(
        "EXPLANATION_MODEL",
        "MBZUAI/LaMini-Flan-T5-783M"
    )

    if _model is None:
        _model = pipeline(
            "text2text-generation",
            model=model_name,
            max_new_tokens=180,
        )

    prompt = (
        "Explain the following topic in simple language for a beginner. "
        "Use a short example if helpful.\n\n"
        f"Topic: {topic}"
    )

    result = _model(prompt)[0]["generated_text"]
    return result.strip()
