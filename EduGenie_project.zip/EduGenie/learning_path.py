from gemini_client import generate


def get_learning_recommendations(topic: str) -> str:
    prompt = f"""
Create a structured learning path for the topic below.

Topic:
{topic}

Include:
1. Beginner concepts
2. Intermediate concepts
3. Advanced concepts
4. A suggested sequence
5. Practice ideas
6. Useful learning resources such as books, articles, or videos

Keep the plan practical and easy to follow.
"""
    return generate(prompt)
