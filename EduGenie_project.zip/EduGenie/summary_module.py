from gemini_client import generate


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational passage.
Keep the important facts, remove repetition, and use clear language.
Return a concise summary suitable for quick revision.

Passage:
{text}
"""
    return generate(prompt)
